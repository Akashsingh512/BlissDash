
insert into user_roles (user_id, role)
values ('dd179c38-9008-43f4-8262-8c25823ac0a7', 'admin');
